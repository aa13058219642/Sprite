//
//  SCSeriko.swift
//  NiseRingoX
//
//  Created by apple  on 2017/8/29.
//  Copyright © 2017年 test. All rights reserved.
//

import Foundation

/*
 SCSeriko
 
 SERIKOの全ての動作の管理を行います。
 */
class SCSeriko {
    // option[exclusive]のシーケンスが動作中の時に true。
    var exclusive_locked = false
    /*private SCSerikoLibrary seriko_lib;
    private Hashtable current_group; // (Integer)scope => group(SCSerikoSeqGroup)
    private SCSerikoBindCenter bindCenter;
    private Vector runners; // [SCSerikoSequenceRunner]
    
    
    // Seriko 停止中なら true。このフィールドは必ず runners に対する
    // synchronized ブロック内で讀み書きしなければならない。
    boolean isStopped;
    
    SCSession session;
    SCShell shell;*/
    
}
