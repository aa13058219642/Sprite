//
//  SCSerikoLibrary.swift
//  NiseRingoX
//
//  Created by apple  on 2017/8/29.
//  Copyright © 2017年 test. All rights reserved.
//

import Foundation

/*
 SCSerikoLibrary
 全てのSERIKOシーケンス記述ファイルの中身を管理します。
 
 バージョンは次の通りです。
 0: SERIKO/1.0
 1: SERIKO/2.0
 */
class SCSerikoLibrary {
    //Vector seqGroups; // 中身はSCSerikoSeqGroup
}
