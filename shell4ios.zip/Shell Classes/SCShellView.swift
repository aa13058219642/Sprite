//
//  SCShellView.swift
//  NiseRingoX
//
//  Created by apple  on 2017/9/10.
//  Copyright © 2017年 test. All rights reserved.
//

//import Cocoa
import UIKit
class SCShellView: UIView {
    static let shareInstance=SCShellView()
    var baseImg:CGImage?
    var rect:CGRect?
    var shellimgView:UIImageView?
    override init(frame frameRect: CGRect) {
        super.init(frame: frameRect)
    }
//    override var isFlipped: Bool {
//        return true
//    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
    }
    
    override func draw(_ dirtyRect: CGRect) {
        //CGColor.clear.set()

        super.draw(dirtyRect)
        
        if baseImg==nil {
            UIRectFill(self.frame)
        } else {
            UIRectFill(self.frame)
            // Drawing code here.
            drawImage(baseImg!)
        }
    }
    
    func drawImage(_ cgImage:CGImage) {
    //let myContext = UIGraphicsImageRendererContext
        //func mask(_ cgimage:CGImage,_ maskimage:CGImage)->CGImage{
           // let colorSpace=CGColorSpaceCreateDeviceGray()//创建一个设备相关的灰度颜色空间的引用
           // let bitmapInfo=CGBitmapInfo(rawValue:CGBitmapInfo().rawValue|CGImageAlphaInfo.none.rawValue)//创建像素位图
           // let context=CGContext(data:nil,width:cgImage.width,height:cgImage.height,bitsPerComponent:8,bytesPerRow:0,space:colorSpace,bitmapInfo:bitmapInfo.rawValue)//创建图形画布，其中宽高度为maskimage的宽高度，maskimage为提供蒙版的文件如PNA，，bitsPerComponent:8代表图片每个颜色所占的bits，图形为32位，每个颜色通道占用8位，共4个通道，RGBA，R=RED，G=GREEN,B=BLUE,A=ALPHA。
           // context?.draw(cgImage,in:CGRect(x:0,y:0,width:cgImage.width,height:cgImage.height))//用创建的图形画布绘制图形
           // let greyImage=context?.makeImage()//将图形画布的图形传递给greyImage
          //  return cgimage.masking(greyImage!)!//将greyImage的图形用作源图形cgimage的图层萌版
      //  }
        
        
      //  Shellview.baseImg = baseImg
        
     
      
        shellimgView = UIImageView(image:UIImage.init(cgImage: cgImage))
        //view.addSubview(ImgView)
        
        
        
        
        
        //let myContext = NSGraphicsContext.current!.cgContext
       // let rect=CGRect(x:0, y:0, width:CGFloat(cgImage.width), height:CGFloat(cgImage.height))
       // myContext.clear(rect)
        //NSImage(cgImage: cgImage, size: NSMakeSize(CGFloat(cgImage.width), CGFloat(cgImage.height))).draw(in: rect)
       // myContext.draw(cgImage, in: rect)
    }
    
}
